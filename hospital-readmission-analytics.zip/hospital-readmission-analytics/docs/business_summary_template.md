# Business Summary: Hospital Readmissions (1 page)

**To:** Hospital Management | **From:** Lavanyaa B S | **Date:** ____

## Problem
30-day readmissions cost money and signal gaps in care. We analysed 100k+ diabetic encounters to find who is most at risk.

## What we found (3 bullets, numbers only)
1. ____% of encounters end in a 30-day readmission; patients with 4+ prior inpatient visits are ____x more likely.
2. ______ (diagnosis) is the largest source of readmissions (____% of the total).
3. Medication change / HbA1c testing / discharge destination: ______ (association strength, p-value).

## Recommendations
1. ______ (action, who owns it, expected impact)
2. ______
3. ______

## Confidence and limits
Observational data, associations not causation, model AUC ____ (modest), 1999-2008 data. Suggested next step: pilot ______ and measure the change.
