"""Step 3: exploratory charts saved to images/ (use them in your README)."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT / "data" / "processed" / "encounters_clean.csv.gz")
IMG = ROOT / "images"
IMG.mkdir(exist_ok=True)
sns.set_theme(style="whitegrid")
overall = df["readmitted_30d"].mean() * 100


def bar_rate(col, title, fname, order=None, min_n=200):
    g = df.groupby(col, observed=True).agg(n=("readmitted_30d", "size"), rate=("readmitted_30d", "mean")).reset_index()
    g = g[g["n"] >= min_n]
    g["rate"] *= 100
    if order is None:
        g = g.sort_values("rate", ascending=False)
    else:
        g = g.set_index(col).reindex([o for o in order if o in set(g[col])]).reset_index()
    fig, ax = plt.subplots(figsize=(8, 4.5))
    sns.barplot(data=g, x=col, y="rate", color="#2a6f97", ax=ax)
    ax.axhline(overall, color="crimson", ls="--", label=f"Overall {overall:.1f}%")
    ax.set(title=title, xlabel="", ylabel="30-day readmission rate (%)")
    ax.legend()
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    fig.savefig(IMG / fname, dpi=150)
    plt.close(fig)
    top = g.loc[g["rate"].idxmax()]
    print(f"{fname}: highest = {top[col]} ({top['rate']:.1f}%)")


bar_rate("age_group", "Readmission rate by age group", "01_readmission_by_age.png", order=["0-30", "30-60", "60-80", "80+"])
bar_rate("diag_group", "Readmission rate by primary diagnosis", "02_readmission_by_diagnosis.png")
bar_rate("admission_type", "Readmission rate by admission type", "03_readmission_by_admission_type.png")
bar_rate("a1c_result", "Readmission rate by HbA1c result", "04_readmission_by_a1c.png")

df["prior_inpatient_band"] = pd.cut(df["number_inpatient"], [-1, 0, 1, 3, 1000], labels=["0", "1", "2-3", "4+"]).astype(str)
bar_rate("prior_inpatient_band", "Readmission rate by prior inpatient visits (past year)",
         "05_readmission_by_prior_inpatient.png", order=["0", "1", "2-3", "4+"])

fig, ax = plt.subplots(figsize=(8, 4.5))
sns.histplot(data=df, x="time_in_hospital", hue="readmitted_30d", multiple="dodge", discrete=True,
             stat="percent", common_norm=False, ax=ax)
ax.set(title="Length of stay: readmitted (1) vs not (0)", xlabel="Days in hospital")
plt.tight_layout()
fig.savefig(IMG / "06_stay_length_distribution.png", dpi=150)
plt.close(fig)

num_cols = ["time_in_hospital", "num_lab_procedures", "num_procedures", "num_medications",
            "number_outpatient", "number_emergency", "number_inpatient", "number_diagnoses", "readmitted_30d"]
fig, ax = plt.subplots(figsize=(8, 6))
sns.heatmap(df[num_cols].corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0, ax=ax)
ax.set_title("Correlation of numeric features")
plt.tight_layout()
fig.savefig(IMG / "07_correlation_heatmap.png", dpi=150)
plt.close(fig)
print("Charts saved to images/")
