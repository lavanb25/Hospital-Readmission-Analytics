"""Step 2: run every named query in sql/*.sql against DuckDB and save results as CSV.

Each query starts with a line like:  -- name: q03_readmission_by_diagnosis
Results are written to outputs/sql_results/<name>.csv
"""
import re
from pathlib import Path

import duckdb

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "data" / "hospital.duckdb"
OUT = ROOT / "outputs" / "sql_results"


def main() -> None:
    if not DB.exists():
        raise SystemExit("Run src/01_clean_data.py first.")
    OUT.mkdir(parents=True, exist_ok=True)
    con = duckdb.connect(str(DB), read_only=True)

    for sql_file in sorted((ROOT / "sql").glob("*.sql")):
        blocks = re.split(r"^-- name:\s*", sql_file.read_text(), flags=re.M)[1:]
        for block in blocks:
            name, _, query = block.partition("\n")
            name = name.strip()
            df = con.execute(query.strip().rstrip(";")).df()
            df.to_csv(OUT / f"{name}.csv", index=False)
            print(f"\n=== {name} ({len(df)} rows) ===")
            print(df.head(8).to_string(index=False))


if __name__ == "__main__":
    main()
