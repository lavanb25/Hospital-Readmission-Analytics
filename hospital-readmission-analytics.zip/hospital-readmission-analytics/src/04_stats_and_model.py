"""Step 4: hypothesis tests + interpretable logistic regression.

Uses each patient's FIRST encounter only, so observations are independent.
Outputs: outputs/stats_tests.csv, outputs/odds_ratios.csv, images/08_odds_ratios.png
"""
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy import stats
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT / "data" / "processed" / "encounters_clean.csv.gz")
first = df[df["is_first_encounter"]].copy()
print(f"First encounters used: {len(first):,} | readmission rate {first['readmitted_30d'].mean():.2%}")

# ---------- 1. Chi-square tests (categorical vs readmission) ----------
rows = []
for col in ["med_change", "age_group", "admission_type", "diag_group", "a1c_result", "discharge_group"]:
    table = pd.crosstab(first[col], first["readmitted_30d"])
    chi2, p, dof, _ = stats.chi2_contingency(table)
    n = table.values.sum()
    cramers_v = np.sqrt(chi2 / (n * (min(table.shape) - 1)))
    rows.append({"test": "chi-square", "variable": col, "statistic": chi2, "dof": dof, "p_value": p, "effect_size": cramers_v})

# ---------- 2. Welch t-tests (numeric, readmitted vs not) ----------
for col in ["time_in_hospital", "num_medications", "number_inpatient", "number_diagnoses"]:
    a = first.loc[first["readmitted_30d"] == 1, col]
    b = first.loc[first["readmitted_30d"] == 0, col]
    t, p = stats.ttest_ind(a, b, equal_var=False)
    pooled_sd = np.sqrt((a.var() + b.var()) / 2)
    rows.append({"test": "welch t-test", "variable": col, "statistic": t, "dof": np.nan, "p_value": p,
                 "effect_size": (a.mean() - b.mean()) / pooled_sd})  # Cohen's d

tests = pd.DataFrame(rows)
(ROOT / "outputs").mkdir(exist_ok=True)
tests.to_csv(ROOT / "outputs" / "stats_tests.csv", index=False)
print("\n", tests.round(4).to_string(index=False))

# ---------- 3. Logistic regression (odds ratios) ----------
formula = (
    "readmitted_30d ~ C(age_group, Treatment('30-60')) + C(admission_type, Treatment('Emergency'))"
    " + C(discharge_group, Treatment('Home')) + C(diag_group, Treatment('Other'))"
    " + C(med_change, Treatment('No change')) + time_in_hospital + num_medications"
    " + number_inpatient + number_emergency + number_outpatient + number_diagnoses"
)
train, test = train_test_split(first, test_size=0.2, random_state=42, stratify=first["readmitted_30d"])
model = smf.logit(formula, data=train).fit(disp=False, maxiter=200)

test_pred = model.predict(test)
auc = roc_auc_score(test["readmitted_30d"], test_pred)
print(f"\nTest AUC: {auc:.3f}  (readmission is hard to predict; the value is in the *interpretation*)")

ci = model.conf_int()
or_df = pd.DataFrame({
    "term": model.params.index,
    "odds_ratio": np.exp(model.params.values),
    "ci_low": np.exp(ci[0].values),
    "ci_high": np.exp(ci[1].values),
    "p_value": model.pvalues.values,
})
or_df = or_df[or_df["term"] != "Intercept"].copy()
or_df["term"] = or_df["term"].apply(lambda t: re.sub(r"C\((\w+), Treatment\('.*?'\)\)\[T\.(.*)\]", r"\1: \2", t))
or_df.to_csv(ROOT / "outputs" / "odds_ratios.csv", index=False)
print("\nSignificant factors (p < 0.05), highest odds ratio first:")
print(or_df[or_df.p_value < 0.05].sort_values("odds_ratio", ascending=False).head(8).round(3).to_string(index=False))

# ---------- 4. Forest plot ----------
plot = or_df.sort_values("odds_ratio").reset_index(drop=True)
fig, ax = plt.subplots(figsize=(8, 0.33 * len(plot) + 1.5))
ax.errorbar(plot["odds_ratio"], range(len(plot)),
            xerr=[plot["odds_ratio"] - plot["ci_low"], plot["ci_high"] - plot["odds_ratio"]],
            fmt="o", color="#2a6f97", capsize=3)
ax.axvline(1, ls="--", color="grey")
ax.set_yticks(range(len(plot)))
ax.set_yticklabels(plot["term"], fontsize=8)
ax.set_xscale("log")
ax.set(xlabel="Odds ratio (log scale, 95% CI)", title="What drives 30-day readmission?")
plt.tight_layout()
(ROOT / "images").mkdir(exist_ok=True)
fig.savefig(ROOT / "images" / "08_odds_ratios.png", dpi=150)
print("\nSaved outputs/stats_tests.csv, outputs/odds_ratios.csv, images/08_odds_ratios.png")
