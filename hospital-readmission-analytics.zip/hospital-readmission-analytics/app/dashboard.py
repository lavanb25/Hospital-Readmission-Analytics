"""Interactive dashboard.  Run:  streamlit run app/dashboard.py"""
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

DATA = Path(__file__).resolve().parents[1] / "data" / "processed" / "encounters_clean.csv.gz"
st.set_page_config(page_title="Hospital Readmission Analytics", page_icon="🏥", layout="wide")


@st.cache_data
def load_data() -> pd.DataFrame:
    d = pd.read_csv(DATA)
    d["prior_inpatient_band"] = pd.cut(d["number_inpatient"], [-1, 0, 1, 3, 1000],
                                       labels=["0", "1", "2-3", "4+"]).astype(str)
    return d


df = load_data()
overall_rate = df["readmitted_30d"].mean() * 100
overall_stay = df["time_in_hospital"].mean()

st.title("🏥 Hospital Readmission Analytics")
st.caption("30-day readmission patterns in 100k+ diabetic hospital encounters (UCI, 130 US hospitals, 1999-2008).")

# ---------------- Sidebar filters ----------------
with st.sidebar:
    st.header("Filters")

    def pick(label, col):
        options = sorted(df[col].dropna().unique())
        return st.multiselect(label, options, default=options)

    ages = pick("Age group", "age_group")
    diags = pick("Primary diagnosis", "diag_group")
    adm = pick("Admission type", "admission_type")
    genders = pick("Gender", "gender")

f = df[df["age_group"].isin(ages) & df["diag_group"].isin(diags)
       & df["admission_type"].isin(adm) & df["gender"].isin(genders)]
if f.empty:
    st.warning("No encounters match these filters.")
    st.stop()

# ---------------- KPIs ----------------
rate = f["readmitted_30d"].mean() * 100
k1, k2, k3, k4 = st.columns(4)
k1.metric("Encounters", f"{len(f):,}")
k2.metric("30-day readmission rate", f"{rate:.1f}%", f"{rate - overall_rate:+.1f} pts vs overall", delta_color="inverse")
k3.metric("Avg stay (days)", f"{f['time_in_hospital'].mean():.1f}", f"{f['time_in_hospital'].mean() - overall_stay:+.1f} vs overall", delta_color="inverse")
k4.metric("Avg medications", f"{f['num_medications'].mean():.1f}")


def rate_by(col, min_n=30):
    g = f.groupby(col).agg(encounters=("readmitted_30d", "size"), rate=("readmitted_30d", "mean")).reset_index()
    g["rate"] *= 100
    return g[g["encounters"] >= min_n]


tab1, tab2, tab3 = st.tabs(["Overview", "Drill-down", "Recommendations"])

with tab1:
    c1, c2 = st.columns(2)
    g = rate_by("age_group").sort_values("age_group")
    fig = px.bar(g, x="age_group", y="rate", hover_data=["encounters"], title="Readmission rate by age group",
                 labels={"rate": "Readmission rate (%)", "age_group": ""})
    fig.add_hline(y=overall_rate, line_dash="dash", line_color="crimson", annotation_text="overall")
    c1.plotly_chart(fig, width="stretch")

    g = rate_by("diag_group").sort_values("rate", ascending=False)
    fig = px.bar(g, x="diag_group", y="rate", hover_data=["encounters"], title="Readmission rate by primary diagnosis",
                 labels={"rate": "Readmission rate (%)", "diag_group": ""})
    fig.add_hline(y=overall_rate, line_dash="dash", line_color="crimson", annotation_text="overall")
    c2.plotly_chart(fig, width="stretch")

    c3, c4 = st.columns(2)
    g = rate_by("prior_inpatient_band")
    g["prior_inpatient_band"] = pd.Categorical(g["prior_inpatient_band"], ["0", "1", "2-3", "4+"], ordered=True)
    fig = px.bar(g.sort_values("prior_inpatient_band"), x="prior_inpatient_band", y="rate", hover_data=["encounters"],
                 title="Prior inpatient visits (past year)", labels={"rate": "Readmission rate (%)", "prior_inpatient_band": "Prior visits"})
    c3.plotly_chart(fig, width="stretch")

    g = rate_by("a1c_result")
    fig = px.bar(g, x="a1c_result", y="rate", hover_data=["encounters"], title="HbA1c testing",
                 labels={"rate": "Readmission rate (%)", "a1c_result": ""})
    c4.plotly_chart(fig, width="stretch")

with tab2:
    st.subheader("Where are the hot spots?")
    heat = f.groupby(["diag_group", "age_group"]).agg(n=("readmitted_30d", "size"), rate=("readmitted_30d", "mean")).reset_index()
    heat = heat[heat["n"] >= 30]
    heat["rate"] *= 100
    if not heat.empty:
        pivot = heat.pivot(index="diag_group", columns="age_group", values="rate")
        fig = px.imshow(pivot, text_auto=".1f", color_continuous_scale="Reds", aspect="auto",
                        labels={"color": "Rate (%)"}, title="Readmission rate (%) by diagnosis x age (cells with n >= 30)")
        st.plotly_chart(fig, width="stretch")

    st.subheader("Length of stay")
    tmp = f.assign(outcome=f["readmitted_30d"].map({1: "Readmitted <30d", 0: "Not readmitted <30d"}))
    fig = px.histogram(tmp, x="time_in_hospital", color="outcome", barmode="group", histnorm="percent",
                       labels={"time_in_hospital": "Days in hospital"}, title="Stay length distribution")
    st.plotly_chart(fig, width="stretch")

    with st.expander("Sample of filtered data"):
        st.dataframe(f.head(200), width="stretch")

with tab3:
    st.subheader("Recommendations for hospital management")
    st.markdown(
        """
        > **Replace the placeholders below with YOUR findings** from `outputs/` after running the pipeline.

        1. **Target high-risk patients before discharge.** Patients with *[X]* prior inpatient visits are *[Y]x* more likely
           to be readmitted. Flag them for a follow-up call within 72 hours.
        2. **Focus on *[diagnosis group]*.** It accounts for *[Z]%* of all 30-day readmissions (see Pareto query `q12`).
        3. **Review discharge destination.** Patients discharged to *[destination]* show the highest odds ratio (*[OR]*).
        4. **Standardise HbA1c testing.** Readmission differs by testing status (*[x%]* vs *[y%]*), but this is
           association, not proof of causation, so recommend a pilot, not a policy.

        **Limitations:** observational data from 1999-2008, one disease population, no cost data, diagnosis grouped from ICD-9.
        """
    )
