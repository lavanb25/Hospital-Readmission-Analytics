"""Step 1: clean the raw UCI diabetes hospital data and load it into DuckDB.

Input : data/raw/diabetic_data.csv
Output: data/processed/encounters_clean.csv.gz  (used by the dashboard + stats)
        data/hospital.duckdb                    (table `encounters`, used by SQL scripts)
"""
from pathlib import Path

import duckdb
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw" / "diabetic_data.csv"
OUT_CSV = ROOT / "data" / "processed" / "encounters_clean.csv.gz"
DB = ROOT / "data" / "hospital.duckdb"

# Discharge ids for patients who died or went to hospice: they cannot be readmitted,
# so keeping them would understate readmission rates.
EXCLUDE_DISCHARGE = [11, 13, 14, 19, 20, 21]

AGE_MAP = {
    "[0-10)": "0-30", "[10-20)": "0-30", "[20-30)": "0-30",
    "[30-40)": "30-60", "[40-50)": "30-60", "[50-60)": "30-60",
    "[60-70)": "60-80", "[70-80)": "60-80",
    "[80-90)": "80+", "[90-100)": "80+",
}
ADMISSION_MAP = {1: "Emergency", 2: "Urgent", 3: "Elective"}


def diag_group(code) -> str:
    """Group raw ICD-9 codes into broad clinical categories."""
    if pd.isna(code):
        return "Unknown"
    code = str(code)
    if code.startswith(("E", "V")):
        return "Other"
    try:
        v = float(code)
    except ValueError:
        return "Other"
    if 250 <= v < 251:
        return "Diabetes"
    if 390 <= v <= 459 or v == 785:
        return "Circulatory"
    if 460 <= v <= 519 or v == 786:
        return "Respiratory"
    if 520 <= v <= 579 or v == 787:
        return "Digestive"
    if 800 <= v <= 999:
        return "Injury"
    if 710 <= v <= 739:
        return "Musculoskeletal"
    if 580 <= v <= 629 or v == 788:
        return "Genitourinary"
    if 140 <= v <= 239:
        return "Neoplasms"
    return "Other"


def discharge_group(i: int) -> str:
    if i == 1:
        return "Home"
    if i in (6, 8):
        return "Home health"
    if i in (2, 3, 4, 5, 22, 23, 24, 27, 28, 29, 30):
        return "Facility transfer"
    return "Other"


def main() -> None:
    if not RAW.exists():
        raise SystemExit(f"Missing {RAW}. See data/README.md for download steps.")

    # '?' marks missing values in this dataset. keep_default_na=False so the
    # literal string 'None' (A1C not tested) is not turned into NaN.
    df = pd.read_csv(RAW, na_values="?", keep_default_na=False)
    print(f"Raw rows: {len(df):,}")

    df = df[~df["discharge_disposition_id"].isin(EXCLUDE_DISCHARGE)].copy()
    print(f"After removing deceased/hospice discharges: {len(df):,}")

    out = pd.DataFrame({
        "encounter_id": df["encounter_id"],
        "patient_nbr": df["patient_nbr"],
        "gender": df["gender"].replace("Unknown/Invalid", pd.NA).fillna("Unknown"),
        "race": df["race"].fillna("Unknown"),
        "age_group": df["age"].map(AGE_MAP),
        "time_in_hospital": df["time_in_hospital"],
        "medical_specialty": df["medical_specialty"].fillna("Unknown"),
        "num_lab_procedures": df["num_lab_procedures"],
        "num_procedures": df["num_procedures"],
        "num_medications": df["num_medications"],
        "number_outpatient": df["number_outpatient"],
        "number_emergency": df["number_emergency"],
        "number_inpatient": df["number_inpatient"],
        "number_diagnoses": df["number_diagnoses"],
        "diag_group": df["diag_1"].map(diag_group),
        "admission_type": df["admission_type_id"].map(ADMISSION_MAP).fillna("Other"),
        "discharge_group": df["discharge_disposition_id"].map(discharge_group),
        "a1c_result": df["A1Cresult"].replace({"None": "Not tested"}),
        "med_change": df["change"].map({"Ch": "Changed", "No": "No change"}),
        "diabetes_med": df["diabetesMed"],
        "readmitted": df["readmitted"],
    })
    out["prior_visits"] = out["number_outpatient"] + out["number_emergency"] + out["number_inpatient"]
    out["readmitted_30d"] = (out["readmitted"] == "<30").astype(int)  # target variable

    # Flag each patient's first encounter. Patients with many encounters are not
    # independent observations, so the statistical model uses first encounters only.
    out = out.sort_values("encounter_id").reset_index(drop=True)
    out["is_first_encounter"] = ~out.duplicated(subset="patient_nbr", keep="first")

    out.to_csv(OUT_CSV, index=False, compression="gzip")

    con = duckdb.connect(str(DB))
    con.register("clean_df", out)
    con.execute("CREATE OR REPLACE TABLE encounters AS SELECT * FROM clean_df")
    con.close()

    print(f"Clean rows: {len(out):,} | unique patients: {out['patient_nbr'].nunique():,}")
    print(f"30-day readmission rate: {out['readmitted_30d'].mean():.2%}")
    print(f"Saved {OUT_CSV.relative_to(ROOT)} and {DB.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
