# Interview Prep: Hospital Readmission Project

## 2-minute pitch
"I analysed 100k hospital encounters to find what drives 30-day readmission. I cleaned the data in Python, loaded it into DuckDB and wrote SQL with CTEs and window functions to segment risk, tested hypotheses with chi-square and t-tests, and fitted a logistic regression to get odds ratios. I then built a Streamlit dashboard and wrote recommendations for hospital management. The biggest driver was ____, and I'd recommend ____."

## Questions to rehearse (write your own answers)
1. **Why did you remove discharge ids 11, 13, 14, 19, 20, 21?** Patients who died or went to hospice cannot be readmitted; keeping them biases the rate downward.
2. **Why first encounters only in the model?** Same patient appears many times, so rows are not independent; this inflates significance.
3. **How did you handle missing data?** `?` values; weight dropped from the analysis (about 97% missing); race/specialty set to "Unknown" so rows are kept and the group is visible.
4. **Why logistic regression, not XGBoost?** The goal is explanation (odds ratios management can act on). AUC is modest either way.
5. **What does an odds ratio of 1.3 mean?** Each extra prior inpatient visit multiplies the odds of readmission by 1.3, holding others constant.
6. **Explain this query line by line:** `q07` (CTE + ROW_NUMBER partition) and `q12` (running total with SUM() OVER).
7. **Difference between WHERE and HAVING? RANK vs ROW_NUMBER vs DENSE_RANK?**
8. **What is a p-value? Why can a tiny p-value with 100k rows still be unimportant?** Mention effect sizes (Cramér's V, Cohen's d).
9. **Correlation vs causation:** why can't you say HbA1c testing *reduces* readmissions?
10. **What would you do with more time/data?** Cost data, time-aware validation, calibration, hospital-level effects.

## SQL drills to practise on top of this project
Running totals, LAG/LEAD for days between visits, self-joins, a cohort query, percentile with `quantile_cont`, `CASE WHEN` bucketing, and finding duplicates with `GROUP BY ... HAVING COUNT(*) > 1`.
