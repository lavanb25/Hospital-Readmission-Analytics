-- Advanced SQL: CTEs, window functions, joins, percentiles.

-- name: q06_high_risk_segments
WITH overall AS (
    SELECT AVG(readmitted_30d) AS overall_rate FROM encounters
),
segments AS (
    SELECT age_group, admission_type,
           COUNT(*)              AS encounters,
           AVG(readmitted_30d)   AS seg_rate
    FROM encounters
    GROUP BY age_group, admission_type
    HAVING COUNT(*) >= 300
)
SELECT s.age_group, s.admission_type, s.encounters,
       ROUND(100 * s.seg_rate, 2)                   AS segment_rate_pct,
       ROUND(100 * (s.seg_rate - o.overall_rate), 2) AS pts_above_overall
FROM segments s CROSS JOIN overall o
ORDER BY pts_above_overall DESC
LIMIT 10;

-- name: q07_top3_specialties_per_diagnosis
WITH base AS (
    SELECT diag_group, medical_specialty,
           COUNT(*) AS n, AVG(readmitted_30d) AS rate
    FROM encounters
    WHERE medical_specialty <> 'Unknown'
    GROUP BY diag_group, medical_specialty
    HAVING COUNT(*) >= 100
),
ranked AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY diag_group ORDER BY rate DESC) AS rn
    FROM base
)
SELECT diag_group, medical_specialty, n AS encounters,
       ROUND(100 * rate, 2) AS readmission_rate_pct
FROM ranked
WHERE rn <= 3
ORDER BY diag_group, rn;

-- name: q08_readmission_by_visit_sequence
WITH seq AS (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY patient_nbr ORDER BY encounter_id) AS visit_no
    FROM encounters
)
SELECT CASE WHEN visit_no >= 4 THEN '4+' ELSE CAST(visit_no AS VARCHAR) END AS visit_number,
       COUNT(*)                              AS encounters,
       ROUND(100.0 * AVG(readmitted_30d), 2) AS readmission_rate_pct
FROM seq
GROUP BY 1
ORDER BY 1;

-- name: q09_long_stay_outliers_by_diagnosis
WITH q AS (
    SELECT diag_group,
           quantile_cont(time_in_hospital, 0.25) AS q1,
           quantile_cont(time_in_hospital, 0.75) AS q3
    FROM encounters
    GROUP BY diag_group
)
SELECT e.diag_group,
       COUNT(*) AS encounters,
       SUM(CASE WHEN e.time_in_hospital > q.q3 + 1.5 * (q.q3 - q.q1) THEN 1 ELSE 0 END) AS long_stay_outliers,
       ROUND(100.0 * SUM(CASE WHEN e.time_in_hospital > q.q3 + 1.5 * (q.q3 - q.q1) THEN 1 ELSE 0 END) / COUNT(*), 2) AS outlier_pct
FROM encounters e
JOIN q ON e.diag_group = q.diag_group
GROUP BY e.diag_group, q.q1, q.q3
ORDER BY outlier_pct DESC;

-- name: q10_a1c_testing_vs_readmission
SELECT a1c_result,
       COUNT(*)                              AS encounters,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct_of_encounters,
       ROUND(100.0 * AVG(readmitted_30d), 2) AS readmission_rate_pct
FROM encounters
GROUP BY a1c_result
ORDER BY readmission_rate_pct DESC;

-- name: q11_readmission_by_medication_count_decile
WITH d AS (
    SELECT *, NTILE(10) OVER (ORDER BY num_medications) AS med_decile
    FROM encounters
)
SELECT med_decile,
       MIN(num_medications) AS min_meds,
       MAX(num_medications) AS max_meds,
       COUNT(*)             AS encounters,
       ROUND(100.0 * AVG(readmitted_30d), 2) AS readmission_rate_pct
FROM d
GROUP BY med_decile
ORDER BY med_decile;

-- name: q12_pareto_of_readmissions_by_diagnosis
WITH by_diag AS (
    SELECT diag_group, SUM(readmitted_30d) AS readmits
    FROM encounters
    GROUP BY diag_group
)
SELECT diag_group, readmits,
       ROUND(100.0 * readmits / SUM(readmits) OVER (), 2) AS pct_of_all_readmissions,
       ROUND(100.0 * SUM(readmits) OVER (ORDER BY readmits DESC) / SUM(readmits) OVER (), 2) AS cumulative_pct
FROM by_diag
ORDER BY readmits DESC;
