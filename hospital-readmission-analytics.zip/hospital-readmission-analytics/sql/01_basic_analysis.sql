-- Table: encounters (one row per hospital encounter). Run via: python src/02_run_sql.py

-- name: q01_overall_kpis
SELECT COUNT(*)                                   AS total_encounters,
       COUNT(DISTINCT patient_nbr)                AS unique_patients,
       SUM(readmitted_30d)                        AS readmitted_within_30d,
       ROUND(100.0 * AVG(readmitted_30d), 2)      AS readmission_rate_pct,
       ROUND(AVG(time_in_hospital), 2)            AS avg_stay_days
FROM encounters;

-- name: q02_readmission_by_age
SELECT age_group,
       COUNT(*)                              AS encounters,
       ROUND(100.0 * AVG(readmitted_30d), 2) AS readmission_rate_pct,
       ROUND(AVG(time_in_hospital), 2)       AS avg_stay_days
FROM encounters
GROUP BY age_group
ORDER BY age_group;

-- name: q03_readmission_by_diagnosis
SELECT diag_group,
       COUNT(*)                              AS encounters,
       ROUND(100.0 * AVG(readmitted_30d), 2) AS readmission_rate_pct,
       RANK() OVER (ORDER BY AVG(readmitted_30d) DESC) AS risk_rank
FROM encounters
GROUP BY diag_group
HAVING COUNT(*) >= 500
ORDER BY risk_rank;

-- name: q04_medication_change_effect
SELECT med_change,
       diabetes_med,
       COUNT(*)                              AS encounters,
       ROUND(100.0 * AVG(readmitted_30d), 2) AS readmission_rate_pct,
       ROUND(AVG(time_in_hospital), 2)       AS avg_stay_days
FROM encounters
GROUP BY med_change, diabetes_med
ORDER BY readmission_rate_pct DESC;

-- name: q05_prior_inpatient_visits
SELECT CASE WHEN number_inpatient = 0 THEN '0'
            WHEN number_inpatient = 1 THEN '1'
            WHEN number_inpatient BETWEEN 2 AND 3 THEN '2-3'
            ELSE '4+' END                    AS prior_inpatient_visits,
       COUNT(*)                              AS encounters,
       ROUND(100.0 * AVG(readmitted_30d), 2) AS readmission_rate_pct
FROM encounters
GROUP BY 1
ORDER BY MIN(number_inpatient);
