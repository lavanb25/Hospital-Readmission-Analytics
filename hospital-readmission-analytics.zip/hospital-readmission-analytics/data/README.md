# Data

**Source:** UCI Machine Learning Repository, *Diabetes 130-US Hospitals for Years 1999-2008*
https://archive.ics.uci.edu/dataset/296/diabetes+130-us+hospitals+for+years+1999-2008

~101,766 hospital encounters, 50 columns (demographics, diagnoses, medications, stay length, readmission outcome).

## How to get it
1. Download the zip from the link above (button: "Download").
2. Unzip and copy `diabetic_data.csv` into `data/raw/`.
3. Run `python src/01_clean_data.py`.

The raw file is not committed (see `.gitignore`). The cleaned file `data/processed/encounters_clean.csv.gz` is committed so the dashboard works without re-running the pipeline.

## Key columns
| Column | Meaning |
|---|---|
| `readmitted` | `<30` readmitted within 30 days, `>30` after 30 days, `NO` never |
| `time_in_hospital` | length of stay in days |
| `number_inpatient / emergency / outpatient` | visits in the year before the encounter |
| `change` | whether diabetes medication was changed during the stay |
| `A1Cresult` | HbA1c test result (or not tested) |
